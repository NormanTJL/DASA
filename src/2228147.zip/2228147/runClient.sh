#!/bin/bash

javac *.java
java client
