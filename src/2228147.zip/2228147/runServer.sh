#!/bin/bash

javac *.java
java server
